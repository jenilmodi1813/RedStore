<?php
include("config.php");

function verifyPassword($inputPassword, $hashedPassword) {
    return password_verify($inputPassword, $hashedPassword);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Retrieve the hashed password from the database for the entered username
    $query = "SELECT * FROM `users` WHERE `username`='$username'";
    $result = mysqli_query($connect, $query);
    $user = mysqli_fetch_assoc($result);

    if ($user && verifyPassword($password, $user['password'])) {
        // Passwords match, user is logged in
        session_start();
        $_SESSION['username'] = $username;
        $_SESSION['user_id'] = $user['id'];

        echo $_SESSION['user_id'];
        
        header("location: index.php"); 
    } else {
        // Passwords do not match, show an error message or handle it as needed
        echo "Invalid username or password";
    }
}
?>
