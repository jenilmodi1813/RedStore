<?php
include("config.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Product - RedStore </title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
    .image{
        height: 270px;
    }
    .account-dropdown:hover .dropdown-content {
    display: block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        z-index: 1;
    }

    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {
        background-color: #f1f1f1;
    }
</style>
</head>
<body>
   
    <div class="container">
        <div class="navbar">
            <div class="logo">
                <img href="index.php" src="RedStore_Img/images/logo.png" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="product.php">Product</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <?php
                        if (isset($_SESSION['user_id'])) {
                            echo '<li class="account-dropdown">';
                            echo '<a href="account.php">' . $_SESSION['username'] . '</a>';
                            echo '<div class="dropdown-content">';
                            echo '<a href="orders.php">Orders</a>';
                            echo '<a href="logout.php">Logout</a>';
                            echo '</div>';
                            echo '</li>';
                        } else {
                            // User is not logged in, display "Account" in the account tab
                            echo '<li><a href="account.php">Account</a></li>';
                        }
                        ?>
                </ul>
            </nav>
            <a href="cart.php"><img src="RedStore_Img/images/cart.png" width="30px" height="30px"></a> 
            <img src="RedStore_Img/images/menu.png" class="menu-icon">
        </div>
       
    </div>



    <!-------featured products ------->
    <div class="small-container">
        <div class="row row-2" >
            <h2>All Product</h2>
            <select >
                <option>Default Shorting </option>\
                <option>Short by price </option>
                <option>Short by popularity </option>
                <option>Short by rating </option>
                <option>Short by sale </option>
            </select>
        </div>
        <div class="row">
            <?php
            // Assuming you have already established a database connection in $connect
            $query = "SELECT * FROM product_variants";
            $sql = mysqli_query($connect, $query);

            while ($row = mysqli_fetch_array($sql)) {
                ?>
                <div class="col-4">
                <a href="product-details.php?product_id=<?php echo $row['variant_id']; ?>">
                    <img class="image" src="Admin/<?php echo $row['image_url']; ?>" alt="Product Image">
                </a>
                    <h4><?php echo $row['variant_name']; ?></h4>
                    <p>&#x20B9;<?php echo $row['price']; ?></p>
                </div>
                <?php
            }
            ?>
        </div>
        </div>

     <!-------Footer------->
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-col-1">
                        <h3>Download Our App</h3>
                        <p>Download App for Android and ios mobile phone.</p>
                        <div class="app-logo">
                            <img src="RedStore_Img/images/play-store.png" >
                            <img src="RedStore_Img/images/app-store.png" >
                        </div>
                    </div>
                    <div class="footer-col-2">
                        <img src="RedStore_Img/images/logo-white.png" >
                        <p>Our Purpose Is To Sustainably Make the Pleasure and
                            Benefits of Sports Accessible to the Many.
                        </p>
                    </div>
                    <div class="footer-col-3">
                        <h3>Useful Links</h3>
                        <ul>
                            <li>Coupons</li>
                            <li>Blog Post</li>
                            <li>Return Policy</li>
                            <li>Join Affiliate</li>
                        </ul>
                    </div>
                    <div class="footer-col-4">
                        <h3>Follow us</h3>
                        <ul>
                            <li>Coupons</li>
                            <li>Facebook</li>
                            <li>Instagram</li>
                            <li>Twitter</li>
                        </ul>
                    </div>
                </div>
                <hr>
                <p class="cr">Copyright 2023</p>
            </div>
        </div>
</body>
</html>