<?php
include('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $message = $_POST["message"];

    $insert_query = "INSERT INTO `contact` (`name`, `email`, `messgae`) VALUES ('$name', '$email', '$message')";

    if (mysqli_query($connect, $insert_query)) {
        header("Location: contact_success.php");
    } else {
        echo "Error storing data in the database: " . mysqli_error($connect);
    }

    // Close the database connection
    mysqli_close($connect);
} else {
    echo "Invalid request";
}
?>
