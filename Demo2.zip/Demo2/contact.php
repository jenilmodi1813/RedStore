<?php
include("config.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Product - RedStore </title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<style>
    .image{
        height: 270px;
    }
        /* Add this to your existing styles or in a separate CSS file */
    .account-dropdown:hover .dropdown-content {
        display: block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        z-index: 1;
    }

    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {
        background-color: #f1f1f1;
    }

</style>
<script>
        document.addEventListener("DOMContentLoaded", function () {
            // Get the form element
            var form = document.querySelector("form");

            // Add event listener for form submission
            form.addEventListener("submit", function (event) {
                // Prevent the default form submission
                event.preventDefault();

                // Validate the form fields
                if (validateForm()) {
                    // If the form is valid, submit the form
                    form.submit();
                }
            });

            // Function to validate the form fields
            function validateForm() {
                var name = document.getElementById("name").value.trim();
                var email = document.getElementById("email").value.trim();
                var message = document.getElementById("message").value.trim();
                var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                // Validate Name
                if (name === "") {
                    displayError("name", "Please enter your name.");
                    return false;
                } else {
                    clearError("name");
                }

                // Validate Email
                if (email === "") {
                    displayError("email", "Please enter your email.");
                    return false;
                } else if (!emailRegex.test(email)) {
                    displayError("email", "Please enter a valid email address.");
                    return false;
                } else {
                    clearError("email");
                }

                // Validate Message
                if (message === "") {
                    displayError("message", "Please enter your message.");
                    return false;
                } else {
                    clearError("message");
                }

                // If all validations pass, return true
                return true;
            }

            // Function to display an error message
            function displayError(field, message) {
                var errorElement = document.getElementById(field + "-error");
                if (errorElement) {
                    errorElement.innerHTML = message;
                }
            }

            // Function to clear an error message
            function clearError(field) {
                var errorElement = document.getElementById(field + "-error");
                if (errorElement) {
                    errorElement.innerHTML = "";
                }
            }
        });
    </script>
</head>
<body>
   
    <div class="container">
        <div class="navbar">
            <div class="logo">
                
                <img href="index.php" src="RedStore_Img/images/logo.png" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.php" class="link-dark link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Home</a></li>
                    <li><a href="product.php" class="link-dark link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Product</a></li>
                    <li><a href="about.php" class="link-dark link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">About</a></li>
                    <li><a href="contact.php" class="link-dark link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Contact</a></li>
                    <?php
                        if (isset($_SESSION['user_id'])) {
                            echo '<li class="account-dropdown">';
                            echo '<a>' . $_SESSION['username'] . '</a>';
                            echo '<div class="dropdown-content">';
                            echo '<a href="orders.php">Orders</a>';
                            echo '<a href="logout.php">Logout</a>';
                            echo '</div>';
                            echo '</li>';
                        } else {
                            // User is not logged in, display "Account" in the account tab
                            echo '<li><a href="account.php" class="link-dark link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Account</a></li>';
                        }   
                        ?>
                </ul>
            </nav>
            <a href="cart.php"><img src="RedStore_Img/images/cart.png" width="30px" height="30px"></a> 
            <img src="RedStore_Img/images/menu.png" class="menu-icon">
        </div>
       
    </div>

    <!-------featured products ------->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">Contact Us</h2>
                        <form action="process_contact.php" method="post">
                        <div class="mb-3">
                            <label for="name" class="form-label">Your Name</label>
                            <input type="text" class="form-control" id="name" name="name">
                            <span id="name-error" class="text-danger"></span>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Your Email</label>
                            <input type="email" class="form-control" id="email" name="email" >
                            <span id="email-error" class="text-danger"></span>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Your Message</label>
                            <textarea class="form-control" id="message" name="message" rows="4" ></textarea>
                            <span id="message-error" class="text-danger"></span>
                        </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

     <!-------Footer------->
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-col-1">
                        <h3>Download Our App</h3>
                        <p>Download App for Android and ios mobile phone.</p>
                        <div class="app-logo">
                            <img src="RedStore_Img/images/play-store.png" >
                            <img src="RedStore_Img/images/app-store.png" >
                        </div>
                    </div>
                    <div class="footer-col-2">
                        <img src="RedStore_Img/images/logo-white.png" >
                        <p>Our Purpose Is To Sustainably Make the Pleasure and
                            Benefits of Sports Accessible to the Many.
                        </p>
                    </div>
                    <div class="footer-col-3">
                        <h3>Useful Links</h3>
                        <ul>
                            <li>Coupons</li>
                            <li>Blog Post</li>
                            <li>Return Policy</li>
                            <li>Join Affiliate</li>
                        </ul>
                    </div>
                    <div class="footer-col-4">
                        <h3>Follow us</h3>
                        <ul>
                            <li>Coupons</li>
                            <li>Facebook</li>
                            <li>Instagram</li>
                            <li>Twitter</li>
                        </ul>
                    </div>
                </div>
                <hr>
                <p class="cr">Copyright 2023</p>
            </div>
        </div>
</body>
</html>