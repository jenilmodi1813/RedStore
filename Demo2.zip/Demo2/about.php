<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RedStore | Ecommerce Website Design</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?
    family=Poppins:wght@300;400;500;600;700&display=swap"
    rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<div class="header">
    <div class="container">
        <div class="navbar">
            <div class="logo">
                <img src="RedStore_Img/images/logo.png" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.php" class="list">Home</a></li>
                    <li><a href="product.php" class="list">Product</a></li>
                    <li><a href="about.php" class="list">About</a></li>
                    <li><a href="contact.php" class="list">Contact</a></li>
                    <!--<li><a href="">Contact</a></li>|-->
                    <li><a href="account.php" class="list">Account</a></li>
                    <li><a href="cart.php" class="list"><img src="RedStore_Img/images/cart.png" width="20px" height="20px"></a></li>
            
                </ul>
            </nav>
            
        </div>
        <div class="row">
            <div class="col-2">
                    <h1>About Us</h1>
                    <p>
                        Join us on this fashion journey, and together, we'll redefine your style, elevate your wardrobe,
                         and make shopping for clothes an exciting adventure.
                         Thank you for choosing REDSTORE
                        as your go-to destination for all things fashion!
                    </p>
                    <p>&nbsp;</p>
                    <p>
                        <b>Quality and Style:</b>
                        <p>We curate a wide range of clothing from trusted brands and emerging designers.
                         Every item in our collection is chosen for its quality, style, and affordability.
                    </p>
                    <p>&nbsp;</p>
                    <p>
                        <b>Trends and Variety:</b>
                        <p>Stay ahead of the fashion curve with our regularly updated collections. 
                        We offer a wide variety of clothing for every occasion, from casual wear to formal attire, and everything in between.
                    </p>
                    <h1>Contact Us</h1>
                    <p>
                        Address :<br><br>
                     10-Ground floor , Acropolic mall , Thaltej , Ahmedabad-380054.
                        <br><br>
                        Call us on - +91 96010 58206 , +91 63545 51841.
                    </p>
            </div>
            <div class="col-2">
                <img src="RedStore_Img/images/image1.png" alt="">

            </div>
        </div>
    </div>
</div>

  
<!-------Footer------->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3>Download Our App</h3>
                <p>Download App for Android and ios mobile phone.</p>
                <div class="app-logo">
                    <img src="RedStore_Img/images/play-store.png" >
                    <img src="RedStore_Img/images/app-store.png" >
                </div>
            </div>
            <div class="footer-col-2">
                <img src="RedStore_Img/images/logo-white.png" >
                <p>Our Purpose Is To Sustainably Make the Pleasure and
                    Benefits of Sports Accessible to the Many.
                </p>
            </div>
            <div class="footer-col-3">
                <h3>Useful Links</h3>
                <ul>
                    <li>Coupons</li>
                    <li>Blog Post</li>
                    <li>Return Policy</li>
                    <li>Join Affiliate</li>
                </ul>
            </div>
            <div class="footer-col-4">
                <h3>Follow us</h3>
                <ul>
                    <li>Coupons</li>
                    <li>Facebook</li>
                    <li>Instagram</li>
                    <li>Twitter</li>
                </ul>
            </div>
        </div>
        <hr>
        <p class="cr">Copyright 2023</p>
    </div>
</div>
</body>
</html>