<?php
session_start();
require_once('config.php');

if (isset($_GET['cart_item_id'])) {
    $cart_item_id = $_GET['cart_item_id'];
    $user_id = $_SESSION['user_id'];

    // Perform the removal from the cart
    $query = "DELETE FROM cart WHERE id = $cart_item_id AND user_id = $user_id";
    mysqli_query($connect, $query);

    // Redirect back to the cart page
    header("Location: cart.php");
    exit();
} else {
    // Redirect to the cart page if cart_item_id is not provided
    header("Location: cart.php");
    exit();
}
?>
