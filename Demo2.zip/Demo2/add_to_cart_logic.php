<?php
session_start();
include('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $product_id = isset($_POST["product_id"]) ? intval($_POST["product_id"]) : 0;
    $size = isset($_POST["size"]) ? $_POST["size"] : "";
    $quantity = isset($_POST["quantity"]) ? intval($_POST["quantity"]) : 0;
    $price = isset($_POST["price"]) ? floatval($_POST["price"]) : 0.0;

    // Validate the data (you should perform more thorough validation)
    if ($product_id <= 0 || !is_numeric($quantity) || $quantity <= 0 || empty($size)) {
        echo "Invalid data";
        exit;
    }

    if (!isset($_SESSION['user_id']) || !is_numeric($_SESSION['user_id'])) {
        echo "User not logged in";
        header("Location: account.php");
        exit;
    }

    $user_id = intval($_SESSION['user_id']);

    // Check if the product is already in the cart for the user
    $existing_query = "SELECT * FROM cart WHERE user_id = ? AND product_id = ? AND size = ?";
    $existing_statement = mysqli_prepare($connect, $existing_query);
    mysqli_stmt_bind_param($existing_statement, "iis", $user_id, $product_id, $size);
    mysqli_stmt_execute($existing_statement);
    $existing_result = mysqli_stmt_get_result($existing_statement);

    if (mysqli_num_rows($existing_result) > 0) {
        // Product already exists in the cart, update the quantity
        $existing_row = mysqli_fetch_assoc($existing_result);
        $existing_quantity = $existing_row['quantity'] + $quantity;

        $update_query = "UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ? AND size = ?";
        $update_statement = mysqli_prepare($connect, $update_query);
        mysqli_stmt_bind_param($update_statement, "iiis", $existing_quantity, $user_id, $product_id, $size);
        $update_result = mysqli_stmt_execute($update_statement);

        if ($update_result) {
            // Output success message (for testing purposes)
            echo "Product quantity updated in cart successfully";
        } else {
            echo "Error updating product quantity in cart: " . mysqli_error($connect);
        }
    } else {
        // Product does not exist in the cart, insert a new entry
        $insert_query = "INSERT INTO cart (user_id, product_id, size, quantity, price) VALUES (?, ?, ?, ?, ?)";
        $insert_statement = mysqli_prepare($connect, $insert_query);
        mysqli_stmt_bind_param($insert_statement, "iiisi", $user_id, $product_id, $size, $quantity, $price);
        $insert_result = mysqli_stmt_execute($insert_statement);

        if ($insert_result) {
            // Output success message (for testing purposes)
            echo "Product added to cart successfully";
        } else {
            echo "Error adding product to cart: " . mysqli_error($connect);
        }
    }

    // Redirect to the cart page after updating or adding to the cart
    header("Location: cart.php");
    exit;
} else {
    echo "Invalid request";
}
?>
