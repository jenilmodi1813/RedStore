<?php
include("config.php");


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // var_dump($_POST);
    $selected_product = $_POST['selected_product'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $image = $_FILES['selectImage']['name'];
    $image_tmp=$_FILES['selectImage']['tmp_name'];

    // File upload handling
    $uploadDirectory = "upload/";  // Directory where uploaded images will be stored
    $uploadFileName = $uploadDirectory . basename($image);

    move_uploaded_file($image_tmp,$uploadFileName);

    $query = "INSERT INTO `product_variants` (`product_id`, `variant_name`, `variant_description`, `price`, `image_url`) VALUES ('$selected_product', '$name', '$description', '$price', 'upload/$image')";

    if (mysqli_query($connect, $query)) {
        // echo "File uploaded.";
        header("location: product_add.php");

    } else {
        echo "Error: " . mysqli_error($connect);
    }
}
?>
