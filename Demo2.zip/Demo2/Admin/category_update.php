<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('location: login.php');
    exit;
}
?>
<?php
include("index.php");
include("config.php"); // Make sure you include "config.php" before attempting to connect to the database

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $name = $_POST['name_product'];
    // Ensure to use single quotes around '$name' and '$id' to prevent SQL injection
    $query = "UPDATE products SET product_name = '$name' WHERE product_id = $id";
    
    if (mysqli_query($connect, $query)) {
        // Redirect to the products page after successful update
        header("Location: category.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($connect);
    }
}

// Retrieve the product data based on the provided ID
$id = $_GET["id"];
$result = mysqli_query($connect, "SELECT * FROM products WHERE product_id = $id");
if ($row = mysqli_fetch_array($result)) {
    $product_name = $row['product_name'];
} else {
    echo "Product not found.";
}
?>

<div id="content">
    <h1>Products</h1>
    <form method="POST" action="">
        <div class="row p-2">
            <div class="form-group col-md-8">
                <label for="name_product">Name Of Category</label>
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <input type="text" class="form-control" id="name_product" value="<?php echo $product_name; ?>" name="name_product">
            </div>
        </div>
        <button type="submit" class="btn btn-primary mt-2">UPDATE</button>
    </form>
</div>
