<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('location: login.php');
    exit;
}
?>
<?php
include("index.php");
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // var_dump($_POST);
    $selected_product = $_POST['selected_product'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $image = $_FILES['selectImage']['name'];
    $image_tmp=$_FILES['selectImage']['tmp_name'];

    // File upload handling
    $uploadDirectory = "upload/";  // Directory where uploaded images will be stored
    $uploadFileName = $uploadDirectory . basename($image);

    move_uploaded_file($image_tmp,$uploadFileName);

    $query = "INSERT INTO `product_variants` (`product_id`, `variant_name`, `variant_description`, `price`, `image_url`) VALUES ('$selected_product', '$name', '$description', '$price', 'upload/$image')";

    if (mysqli_query($connect, $query)) {
        // echo "File uploaded.";
        header("location: product_add.php");

    } else {
        echo "Error: " . mysqli_error($connect);
    }
}
?>

<div id="content">
    <h1>Products / <span>ADD</span></h1>
    <form method="POST" action="" enctype="multipart/form-data">
        <div class="row p-2">
            <div class="form-group col-md-6">
                <label for="selected_product">Select Parent Product</label>
                <select class="form-control" name="selected_product" id="selected_product">
                    <option selected>Select a parent product</option>
                    <?php
                    $query = "SELECT * FROM products";
                    $result = mysqli_query($connect, $query);

                    while ($row = mysqli_fetch_array($result)) {
                        echo '<option value="' . $row['product_id'] . '">' . $row['product_name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label>Enter Name</label>
                <input type="text" class="form-control" id="name" name="name">
            </div>
        </div>
        <div class="row p-2">
            <div class="form-group col-md-6">
                <label>Price</label>
                <input type="text" class="form-control" id="price" name="price">
            </div>
            <div class="form-group col-md-6">
                <div class="custom-file">
                    <label for="selectImage">Choose file</label>
                    <input type="file" class="form-control" id="selectImage" name="selectImage">
                </div>
            </div>
        </div>
        <div class="row p-2">
            <div class="form-group col-md-12">
                <label>Description</label>
                <textarea class="form-control" id="description" name="description" rows="3"></textarea>
            </div>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Submit</button>
    </form>
</div>

