<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('location: login.php');
    exit;
}
?>
<?php
include("index.php");
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    $query = "INSERT INTO `users` (`username`, `email`, `password`, `role`)
            VALUES ('$username', '$email', '$hashedPassword', '$role')";

    mysqli_query($connect, $query);
    header("location: users.php");
}
?>

<div id="content">
    <h1>Products / <span>ADD</span></h1>
    <form method="POST" action="" enctype="multipart/form-data">
        <div class="row p-2">
            <div class="form-group col-md-12">
                <label>Username</label>
                <input type="text" class="form-control" id="username" name="username">
            </div>
        </div>
        <div class="row p-2">
            <div class="form-group col-md-12">
                <label>Email</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
        </div>
        <div class="row p-2">
            <div class="form-group col-md-12">
                <label>Password</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>
        </div>
        <div class="row p-2">
            <div class="form-group col-md-12">
                <label>Role</label>
                <select class="form-control" id="role" name="role">
                    <option value="">Select Role</option>
                    <option value="admin">Admin</option>
                    <option value="customer">Customer</option>
                </select>
            </div>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Submit</button>
    </form>
</div>

