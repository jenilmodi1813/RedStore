<?php
include("config.php");
  $id = $_GET["id"];
  $result = mysqli_query($connect, "DELETE FROM products WHERE product_id=$id");
  header("location:category.php");
?>