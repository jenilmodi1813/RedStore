<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('location: login.php');
    exit;
}
?>
<?php
include("index.php");
include("config.php");

// Load the record to edit
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM orders WHERE id = $id";
    $result = mysqli_query($connect, $query);
    $row = mysqli_fetch_array($result);
} else {
    // Handle cases when editing a specific record is not requested
    header("location: orders.php");
}
?>

<div id="content">
    <h1>Order / <span>View</span></h1>
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <!-- Add a hidden input field to store the product variant ID -->
        <table class="table">
            <tr>
                <th colspan="6">ORDER ID:- <?php echo $row['id']; ?></th>
            </tr>
            <tr>
                <th>First Name</th>
                <td><?php echo $row['first_name']; ?></td>
                <th>Last Name</th>
                <td><?php echo $row['last_name']; ?></td>
                <th>Order Date</th>
                <td><?php echo $row['order_date']; ?></td>
            </tr>
            <tr>
                <th>Address</th>
                <td><?php echo $row['address']; ?></td>
                <th>City</th>
                <td><?php echo $row['city']; ?></td>
                <th>Stat</th>
                <td><?php echo $row['state']; ?></td>
            </tr>
            <tr>
                <th>Pincode</th>
                <td><?php echo $row['pincode']; ?></td>
                <td></td>
                <td></td>
                <th>Mobile Number</th>
                <td><?php echo $row['mobile_number']; ?></td>
            </tr>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th>Amount</th>
                <td><?php echo $row['subtotal']; ?></td>
            </tr>
        </table>
        <hr></hr>
        <h3>Order / <span>Associated</span></h3>
        <table class="table">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Product Name</th>
                <th scope="col">Product Quantity</th>
                <th scope="col">Product Price</th>
            </tr>
            <?php
            $query2 = "SELECT 
                        order_items.order_item_id AS order_item_id,
                        order_items.*,
                        product_variants.variant_name,
                        product_variants.image_url
                    FROM 
                        order_items
                    LEFT JOIN 
                        product_variants ON order_items.product_id = product_variants.variant_id
                    WHERE 
                        order_items.order_id = $id";

            $result2 = mysqli_query($connect, $query2);

            $totalAMount = 0;

            $count = 1; // Counter for row number

            while ($row = mysqli_fetch_assoc($result2)) {
                echo "<tr>";
                echo '<td><img src="'. $row['image_url'] . '" width="100" height="100" alt="Product Image"></td>';
                echo "<td>" . $row['variant_name'] . "</td>";
                echo "<td>" . $row['quantity'] . "</td>";
                echo "<td>" . $row['price'] . "</td>";
                $totalAMount += $row['price'];
                echo "</tr>";
            }
            ?>
        <tfoot>
            <tr>
                <th></th>
                <th></th>
                <th>Total Amount</th>
                <td><?php echo $totalAMount; ?></td>
            </tr>
        </tfoot>
    </table>
        <a href="orders.php" class="btn btn-primary mt-2">Cancel</a>
</div>
