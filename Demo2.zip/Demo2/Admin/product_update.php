<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('location: login.php');
    exit;
}
?>
<?php
include("index.php");
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_product'])) {
    $id = $_POST['id'];
    $selected_product = $_POST['selected_product'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    // Check if a new image is uploaded
    if (!empty($_FILES['selectImage']['name'])) {
        $image = $_FILES['selectImage']['name'];
        $image_tmp = $_FILES['selectImage']['tmp_name'];

        // File upload handling
        $uploadDirectory = "upload/";  // Directory where uploaded images will be stored
        $uploadFileName = $uploadDirectory . basename($image);

        if (move_uploaded_file($image_tmp, $uploadFileName)) {
            // If a new image is uploaded, update the image_url in the database
            $updateQuery = "UPDATE `product_variants` SET 
                            `product_id` = '$selected_product', 
                            `variant_name` = '$name', 
                            `variant_description` = '$description', 
                            `price` = '$price', 
                            `image_url` = 'upload/$image' 
                            WHERE `variant_id` = $id";
        }
    } else {
        // If no new image is uploaded, update the record without changing the image_url
        $updateQuery = "UPDATE `product_variants` SET 
                        `product_id` = '$selected_product', 
                        `variant_name` = '$name', 
                        `variant_description` = '$description', 
                        `price` = '$price' 
                        WHERE `variant_id` = $id";
    }

    if (mysqli_query($connect, $updateQuery)) {
        // Redirect to a success page or perform other actions as needed
        header("location: product.php");
    } else {
        echo "Error: " . mysqli_error($connect);
    }
}

// Load the record to edit
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM product_variants WHERE variant_id = $id";
    $result = mysqli_query($connect, $query);
    $row = mysqli_fetch_array($result);
} else {
    // Handle cases when editing a specific record is not requested
    header("location: product_add.php");
}
?>

<div id="content">
    <h1>Products / <span>EDIT</span></h1>
    <form method="POST" action="" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $row['variant_id']; ?>">
        <!-- Add a hidden input field to store the product variant ID -->

        <div class="row p-2">
            <div class="form-group col-md-6">
                <label for="selected_product">Select Parent Product</label>
                <select class="form-control" name="selected_product" id="selected_product">
                    <option selected>Select a parent product</option>
                    <?php
                    // Fetch and display available parent products from the database
                    $query = "SELECT * FROM products";
                    $result = mysqli_query($connect, $query);

                    while ($parentProduct = mysqli_fetch_array($result)) {
                        $selected = ($parentProduct['product_id'] == $row['product_id']) ? 'selected' : '';
                        echo '<option value="' . $parentProduct['product_id'] . '" ' . $selected . '>' . $parentProduct['product_name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label>Enter Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo $row['variant_name']; ?>">
            </div>
        </div>
        <div class="row p-2">
            <div class="form-group col-md-6">
                <label>Price</label>
                <input type="text" class="form-control" id="price" name="price" value="<?php echo $row['price']; ?>">
            </div>
            <div class="form-group col-md-6">
                <div class="custom-file">
                    <label for="selectImage">Choose file</label>
                    <input type="file" class="form-control" id="selectImage" name="selectImage">
                </div>
            </div>
        </div>
        <div class="row p-2">
            <div class="form-group col-md-12">
                <label>Description</label>
                <textarea class="form-control" id="description" name="description" rows="3"><?php echo $row['variant_description']; ?></textarea>
            </div>
        </div>
        <button type="submit" name="update_product" class="btn btn-primary mt-2">Update</button>
    </form>
</div>
