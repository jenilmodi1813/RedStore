<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('location: login.php');
    exit;
}
?>
<?php
include("index.php");
include("config.php");

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name_product'];
    $query = "INSERT INTO `products` (`product_name`) VALUES ('$name')";
    
    if (mysqli_query($connect, $query)) {
        // Redirect to the products page after successful insertion
        header("Location: category.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($connect);
    }
}
?>

<div id="content">
    <h1>Products</h1>
    <form method="POST" action="">
        <div class="row p-2">
            <div class="form-group col-md-8">
                <label for="name_product">Name Of Category</label>
                <input type="text" class="form-control" id="name_product" name="name_product">
            </div>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Submit</button>
    </form>
</div>
