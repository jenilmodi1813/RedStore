<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('location: login.php');
    exit;
}
?>
<?php
include("index.php");
include("config.php");

// Update user information when the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Check if a new password is provided; if not, retain the existing password
    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $updatePassword = "password='$hashedPassword', ";
    } else {
        $updatePassword = '';
    }

    $query = "UPDATE `users` SET 
        username='$username',
        email='$email',
        {$updatePassword}
        role='$role'
        WHERE id='$id'";

    mysqli_query($connect, $query);
    header("location: users.php");
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM users WHERE id = $id";
    $result = mysqli_query($connect, $query);
    $row = mysqli_fetch_array($result);
} else {
    // Handle cases when editing a specific record is not requested
    header("location: product_add.php");
}
?>

<div id="content">
    <h1>Users / <span>EDIT</span></h1>
    <form method="POST" action="" enctype="multipart/form-data">
        <div class="row p-2">
            <div class="form-group col-md-12">
                <label>Username</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo $row['username']; ?>">
            </div>
        </div>
        <div class="row p-2">
            <div class="form-group col-md-12">
                <label>Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>">
            </div>
        </div>
        <div class="row p-2">
            <div class="form-group col-md-12">
                <label>Password (leave blank to keep existing)</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>
        </div>
        <div class="row p-2">
            <div class="form-group col-md-12">
                <label>Role</label>
                <select class="form-control" id="role" name="role">
                    <option value="">Select Role</option>
                    <option value="admin" <?php echo ($row['role'] === 'admin') ? 'selected' : ''; ?>>Admin</option>
                    <option value="customer" <?php echo ($row['role'] === 'customer') ? 'selected' : ''; ?>>Customer</option>
                </select>
            </div>
        </div>
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>"> <!-- Hidden field to send user ID for update -->
        <button type="submit" class="btn btn-primary mt-2">Update</button>
    </form>
</div>
