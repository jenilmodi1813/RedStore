<?php
include("config.php");
  $id = $_GET["id"];
  $result = mysqli_query($connect, "DELETE FROM product_variants WHERE variant_id=$id");
  header("location:product.php");
?>