<?php
//database Connection

$connect=mysqli_connect("localhost","root","","demo");
?>