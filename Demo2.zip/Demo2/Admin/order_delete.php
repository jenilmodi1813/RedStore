<?php
include("config.php");
  $id = $_GET["id"];
  $result = mysqli_query($connect, "DELETE FROM orders WHERE id=$id");
  header("location:orders.php");
?>