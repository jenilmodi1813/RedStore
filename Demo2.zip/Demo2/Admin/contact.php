<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('location: login.php');
    exit;
}
?>
<?php
include("index.php");
include("config.php");
?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<div id="content">
<h1>Orders</h1>
<div class="d-flex justify-content-end mb-5">
    <!-- <a href="product_add.php" class="btn btn-primary">ADD PRODUCT</a> -->
</div>
    <table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>#</th>
                <th>name</th>
                <th>email</th>
                <th>message</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $user_id=$_SESSION['id'];
            $num=1;
            $query="SELECT * from contact";
            // WHERE orders.user_id = $user_id";
            $sql=mysqli_query($connect,$query);
            while($row = mysqli_fetch_array($sql)){
            ?>
                <tr>
                    <td><?php echo $num; $num++?></td>
                    <td><?php echo $row["name"];?></td>
                    <td><?php echo $row["email"];?></td>
                    <td><?php echo $row["messgae"];?></td>
                    <td>
                        <a href="order_view.php?id=<?php echo $row['id'];?>" class="btn btn-primary">VIEW</a> 
                        <!-- <a href="order_delete.php?id=<?php echo $row['id'];?>" class="btn btn-danger" onClick="return confirm('Are you sure you want to delete?')">DELETE</a>  -->
                    </td>
                </tr>
            <?php }?>
        </tbody>
    </table>
</div>

<!-- Include DataTables jQuery and DataTables CSS -->
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
    // Initialize the DataTable
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
