<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('location: login.php');
    exit;
}
?>
<?php
include("index.php");
include("config.php");
?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<div id="content">
<div class="d-flex justify-content-end mb-5">
    <a href="user_add.php" class="btn btn-primary">ADD USER</a>
</div>
    <table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $num=1;
            $query="SELECT * FROM users";
            $sql=mysqli_query($connect,$query);
            while($row = mysqli_fetch_array($sql)){
            ?>
                <tr>
                    <td><?php echo $num; $num++?></td>
                    <td><?php echo $row["username"];?></td>
                    <td><?php echo $row["email"];?></td>
                    <td><?php echo $row["role"];?></td>
                    <td>
                        <a href="user_update.php?id=<?php echo $row['id'];?>" class="btn btn-success">EDIT</a> 
                        <a href="user_delete.php?id=<?php echo $row['id'];?>" class="btn btn-danger" onClick="return confirm('Are you sure you want to delete?')">DELETE</a> 
                    </td>
                </tr>
            <?php }?>
        </tbody>
    </table>
</div>

<!-- Include DataTables jQuery and DataTables CSS -->
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
    // Initialize the DataTable
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
