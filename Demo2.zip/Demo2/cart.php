<?php
session_start();
require_once('config.php');

if (!isset($_SESSION['username'])) {
    header("Location: account.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Product - RedStore</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
         .account-dropdown:hover .dropdown-content {
        display: block;
        color: black;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        z-index: 1;
    }

    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {
        background-color: #f1f1f1;
    }
    </style>
</head>

<body>
    <div class="container">
        <div class="navbar">
            <div class="logo">
                <img href="index.php" src="RedStore_Img/images/logo.png" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.php" class="link-dark link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Home</a></li>
                    <li><a href="product.php" class="link-dark link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Product</a></li>
                    <li><a href="about.php" class="link-dark link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">About</a></li>
                    <li><a href="contact.php" class="link-dark link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Contact</a></li>
                    <?php
                        if (isset($_SESSION['user_id'])) {
                            echo '<li class="account-dropdown">';
                            echo '<a>' . $_SESSION['username'] . '</a>';
                            echo '<div class="dropdown-content">';
                            echo '<a href="logout.php">Logout</a>';
                            echo '</div>';
                            echo '</li>';
                        } else {
                            // User is not logged in, display "Account" in the account tab
                            echo '<li><a href="account.php">Account</a></li>';
                        }
                        ?>
                </ul>
            </nav>
            <img src="RedStore_Img/images/menu.png" class="menu-icon">
        </div>
    </div>

    <div class="small-container cart-page">
        <table>
            <tr>
                <th class="t">Product</th>
                <th>Quantity</th>
                <th>Subtotal</th>
                <th>Action</th>
            </tr>

            <?php
            require_once('config.php');

            // Fetch cart items from the database
            $user_id = $_SESSION['user_id'];
            $query = "SELECT c.*, pv.variant_name, pv.price, pv.image_url 
                      FROM cart c
                      JOIN product_variants pv ON c.product_id = pv.variant_id
                      WHERE c.user_id = $user_id";
            $result = mysqli_query($connect, $query);

            // Check if there are any items in the cart
            $total=0;
            if (mysqli_num_rows($result) > 0) {
                
                while ($row = mysqli_fetch_assoc($result)) {
                    $product_name = $row['variant_name'];
                    $price = $row['price'];
                    $quantity = $row['quantity'];
                    $subtotal = $quantity * $price;
                    $total+=$subtotal;
                    $cart_item_id = $row['id'];

                    echo "<tr>";
                    echo "<td>";
                    echo "<div class='cart-info'>";
                    echo "<img src='Admin/{$row['image_url']}'>";
                    echo "<div class='t'>";
                    echo "<p>{$product_name}</p>";
                    echo "<small>Price: &#x20B9;{$price}</small>";
                    echo "</div>";
                    echo "</div>";
                    echo "</td>";
                    echo "<td><input type='number' value='{$quantity}'></td>";
                    echo "<td>&#x20B9;{$subtotal}</td>";
                    echo "<td><a href='cart_remove.php?cart_item_id={$cart_item_id}'>Remove</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>Your cart is empty</td></tr>";
            }
            ?>
        </table>

        <div class="total-price">
            <table>
                <tr>
                    <td class="a">Subtotal</td>
                    <td>&#x20B9;<?php echo $total; ?></td>
                </tr>
            </table>
            
        </div>
        <button onclick="openModal()">Place Order</button>
    </div>

    <div class="modal fade" id="orderModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Order Summary</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Display product details, subtotal, and tax -->
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Product</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Display product details in the modal
                        $query = "SELECT c.*, pv.variant_name, pv.price 
                                  FROM cart c
                                  JOIN product_variants pv ON c.product_id = pv.variant_id
                                  WHERE c.user_id = $user_id";
                        $result = mysqli_query($connect, $query);

                        while ($row = mysqli_fetch_assoc($result)) {
                            $product_name = $row['variant_name'];
                            $quantity = $row['quantity'];
                            $price = $row['price'];
                            $product_id = $row['product_id'];

                            echo "<tr>"; 
                            echo "<td></td>";
                            echo "<td>{$product_name}</td>";
                            echo "<td>{$quantity}</td>";
                            echo "<td>&#x20B9;{$price}</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>

                <!-- Display subtotal, tax, and total -->
                <p>Total: &#x20B9;<?php echo $total; ?></p>

                <!-- Form for entering address, city, state, pincode, mobile_number -->
                <form action="place_order.php" method="post">
                    <!-- Add your existing form fields here -->

                    <!-- Additional hidden input to submit the order -->
                    <input type="hidden" name="place_order" value="1">
                    

                    <!-- New input fields for address, city, state, pincode, mobile_number -->
                    <div class="form-group">
                        <label for="address">First Name:</label>
                        <input type="text" class="form-control" id="first_name" name="first_name" required>
                        <input type="hidden" name="place_order" value="<?php echo $product_id; ?>">
                    </div>

                    <div class="form-group">
                        <label for="address">Last Name:</label>
                        <input type="text" class="form-control" id="last_name" name="last_name" required>
                    </div>

                    <div class="form-group">
                        <label for="address">Address:</label>
                        <input type="text" class="form-control" id="address" name="address" required>
                    </div>

                    <div class="form-group">
                        <label for="city">City:</label>
                        <input type="text" class="form-control" id="city" name="city" required>
                    </div>

                    <div class="form-group">
                        <label for="state">State:</label>
                        <input type="text" class="form-control" id="state" name="state" required>
                    </div>

                    <div class="form-group">
                        <label for="pincode">Pincode:</label>
                        <input type="text" class="form-control" id="pincode" name="pincode" required>
                    </div>

                    <div class="form-group">
                        <label for="mobile_number">Mobile Number:</label>
                        <input type="text" class="form-control" id="mobile_number" name="mobile_number" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Place Order</button>
                </form>
            </div>
        </div>
    </div>
</div>

    <!-------Footer------->
    <div class="footer">
                <div class="container">
                    <div class="row">
                        <div class="footer-col-1">
                            <h3>Download Our App</h3>
                            <p>Download App for Android and ios mobile phone.</p>
                            <div class="app-logo">
                                <img src="RedStore_Img/images/play-store.png" >
                                <img src="RedStore_Img/images/app-store.png" >
                            </div>
                        </div>
                        <div class="footer-col-2">
                            <img src="RedStore_Img/images/logo-white.png" >
                            <p>Our Purpose Is To Sustainably Make the Pleasure and
                                Benefits of Sports Accessible to the Many.
                            </p>
                        </div>
                        <div class="footer-col-3">
                            <h3>Useful Links</h3>
                            <ul>
                                <li>Coupons</li>
                                <li>Blog Post</li>
                                <li>Return Policy</li>
                                <li>Join Affiliate</li>
                            </ul>
                        </div>
                        <div class="footer-col-4">
                            <h3>Follow us</h3>
                            <ul>
                                <li>Coupons</li>
                                <li>Facebook</li>
                                <li>Instagram</li>
                                <li>Twitter</li>
                            </ul>
                        </div>
                    </div>
                    <hr>
                    <p class="cr">Copyright 2023</p>
                </div>
            </div>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    // Function to open the modal
    function openModal() {
        $('#orderModal').modal('show');
    }

    // Function to close the modal
    function closeModal() {
        $('#orderModal').modal('hide');
    }
</script>
</html>

<?php
function calculateSubtotal($connect, $user_id)
{
    $subtotal = 0;

    $query = "SELECT c.quantity, pv.price
              FROM cart c
              JOIN product_variants pv ON c.product_id = pv.variant_id
              WHERE c.user_id = $user_id";
    $result = mysqli_query($connect, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $subtotal += $row['quantity'] * $row['price'];
    }

    return $subtotal;
}

function calculateTax($connect, $user_id)
{
    return 0.1 * calculateSubtotal($connect, $user_id);
}

function calculateTotal($connect, $user_id)
{
    return calculateSubtotal($connect, $user_id) + calculateTax($connect, $user_id);
}
?>
