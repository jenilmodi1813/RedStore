<?php
session_start();
require_once('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["place_order"])) {
    // Fetch user ID from the session
    $user_id = $_SESSION['user_id'];

    // Fetch cart items for the specific user
    $query = "SELECT c.*, pv.price
              FROM cart c
              JOIN product_variants pv ON c.product_id = pv.variant_id
              WHERE c.user_id = $user_id";
    $result = mysqli_query($connect, $query);

    // Check if there are any items in the cart
    if (mysqli_num_rows($result) > 0) {
        // Calculate subtotal, tax, and total
        $subtotal = 0;
        while ($row = mysqli_fetch_assoc($result)) {
            $subtotal += $row['quantity'] * $row['price'];
        }

        // Insert order into the orders table
        $first_name = mysqli_real_escape_string($connect, $_POST['first_name']);
        $last_name = mysqli_real_escape_string($connect, $_POST['last_name']);
        $address = mysqli_real_escape_string($connect, $_POST['address']);
        $city = mysqli_real_escape_string($connect, $_POST['city']);
        $state = mysqli_real_escape_string($connect, $_POST['state']);
        $pincode = mysqli_real_escape_string($connect, $_POST['pincode']);
        $mobile_number = mysqli_real_escape_string($connect, $_POST['mobile_number']);

        $insert_order_query = "INSERT INTO orders (user_id, order_date, first_name, last_name, address, city, state, pincode, mobile_number, subtotal)
                               VALUES ($user_id, NOW(), '$first_name', '$last_name', '$address', '$city', '$state', '$pincode', '$mobile_number', $subtotal)";
        $result_insert_order = mysqli_query($connect, $insert_order_query);

        if ($result_insert_order==1) {
            $order_id = mysqli_insert_id($connect);

            $move_to_order_items_query = "INSERT INTO `order_items` (`order_id`, `product_id`, `quantity`, `price`)
                                          SELECT $order_id, product_id, quantity, price
                                          FROM cart
                                          WHERE user_id = $user_id";
            $result_move_to_order_items = mysqli_query($connect, $move_to_order_items_query);

            if ($result_move_to_order_items) {
                // Remove cart items after successful order placement
                $remove_from_cart_query = "DELETE FROM cart WHERE user_id = $user_id";
                $result_remove_from_cart = mysqli_query($connect, $remove_from_cart_query);

                if ($result_remove_from_cart) {
                    header("Location: suceess.php?order_id=$order_id&first_name=$first_name&last_name=$last_name&address=$address&city=$city&state=$state&pincode=$pincode&mobile_number=$mobile_number&subtotal=$subtotal");
                } else {
                    echo "Error removing cart items: " . mysqli_error($connect);
                }
            } else {
                echo "Error moving items to order_items: " . mysqli_error($connect);
            }
        } else {
            echo "Error placing order: " . mysqli_error($connect);
        }
    } else {
        echo "Your cart is empty.";
    }
} else {
    echo "Invalid request.";
}
?>
