<?php
include("config.php");
$id=$_GET['order_id'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Order Success</title>
    <!-- Add Bootstrap CSS link -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Add Bootstrap JS and Popper.js script links (order is important) -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            margin-top: 50px;
            text-align: center;
        }

        .success-message {
            font-size: 24px;
            color: #28a745;
        }

        .print-friendly {
            display: none;
        }

        @media print {
            /* Hide elements when printing */
            .hide-on-print {
                display: none;
            }

            /* Show the print-friendly container when printing */
            .print-friendly {
                display: block !important;
            }
        }
    </style>

    
<script>
    function printOrderDetails() {
        $('.hide-on-print').hide();
        window.print();
        $('.hide-on-print').show();
    }
</script>

</head>

<body>

<div class="container">
    <h1 class="success-message">Order Placed Successfully!</h1>
    <p class="lead">Thank you for your purchase. Your order (ID: <?php echo htmlspecialchars($_GET['order_id']); ?>) has been successfully placed.</p>
    <p class="hide-on-print">You will receive an email confirmation shortly.</p>
    <a href="index.php" class="btn btn-primary hide-on-print">Back to Home</a>
    <button class="btn btn-success hide-on-print" onclick="printOrderDetails()">Print Order Details</button>

    <div class="print-friendly">
    <h2>Order Details</h2>
    <table class="table table-bordered">
        <tbody>
            <tr>
                <th colspan="2">Order ID:</th>
                <td colspan="2"><?php echo htmlspecialchars($_GET['order_id']); ?></td>
            </tr>
            <tr>
                <th colspan="2">Order Date:</th>
                <td colspan="2"><?php echo date("Y-m-d H:i:s"); ?></td>
            </tr>
            <tr>
                <th colspan="2">First Name:</th>
                <td colspan="2"><?php echo htmlspecialchars($_GET['first_name']); ?></td>
            </tr>
            <tr>
                <th colspan="2">Last Name:</th>
                <td colspan="2"><?php echo htmlspecialchars($_GET['last_name']); ?></td>
            </tr>
            <tr>
                <th colspan="2">Address:</th>
                <td colspan="2"><?php echo htmlspecialchars($_GET['address']); ?></td>
            </tr>
            <tr>
                <th colspan="2">City:</th>
                <td colspan="2"><?php echo htmlspecialchars($_GET['city']); ?></td>
            </tr>
            <tr>
                <th colspan="2">State:</th>
                <td colspan="2"><?php echo htmlspecialchars($_GET['state']); ?></td>
            </tr>
            <tr>
                <th colspan="2">Pincode:</th>
                <td colspan="2"><?php echo htmlspecialchars($_GET['pincode']); ?></td>
            </tr>
            <tr>
                <th colspan="2">Mobile Number:</th>
                <td colspan="2"><?php echo htmlspecialchars($_GET['mobile_number']); ?></td>
            </tr>
            <tr>
                <th colspan="2">Total:</th>
                <td colspan="2"><?php echo number_format($_GET['subtotal']); ?></td>
            </tr>
            <tr>
                <th colspan="4">Orders Details</th>
            </tr>
            <?php
                $last_data_query = "SELECT order_items.*, product_variants.variant_name
                                    FROM order_items 
                                    INNER JOIN product_variants ON order_items.product_id = product_variants.variant_id
                                    WHERE order_items.order_id = $id";
                $last_data_result = mysqli_query($connect, $last_data_query);

                if ($last_data_result === false) {
                    echo "Error: " . mysqli_error($connect);
                } else {
                    $number = 1;
                    
                    while ($last_data_row = mysqli_fetch_assoc($last_data_result)) {
                        echo '<tr>';
                        echo '<td>' . $number . '</td>';
                        echo '<td>' . $last_data_row['variant_name'] . '</td>';
                        echo '<td>' . $last_data_row['quantity'] . '</td>';
                        echo '<td>' . $last_data_row['price'] . '</td>';
                        // Add more columns as needed
                        echo '</tr>';
                        $number++;
                    }
                    mysqli_free_result($last_data_result);
                }
            ?>
        </tbody>
    </table>
</div>
</div>
</body>
</html>
