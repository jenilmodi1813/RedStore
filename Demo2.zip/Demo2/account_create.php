<?php
include("config.php");

$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];

// Hash the password
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

$query = "INSERT INTO `users` (`username`, `email`, `password`, `role`)
          VALUES ('$username', '$email', '$hashedPassword', 'customer')";

mysqli_query($connect, $query);
header("location: account.php");
?>
